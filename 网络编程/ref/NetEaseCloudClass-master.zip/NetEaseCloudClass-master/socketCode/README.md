# 全面学习网络编程

> 如果你对c语言编程和socket哪怕一窍不通，可能通过阅读这份代码也能基本掌握soket编程的知识
> 学习没有捷径，唯一的捷径就是不走弯路

* 判定主机字节序
	- byteorder

* 测试listen
	- testlisten.c

* 测试accept
	- testaccept.c
	
* TCP读写测试
	- testoobrecv.c
	- testoobsend.c
